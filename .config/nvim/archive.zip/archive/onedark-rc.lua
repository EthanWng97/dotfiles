require('onedark').setup{
	transparent = true,
	transparent_sidebar = true,
	highlight_linenumber = true,
	dark_sidebar = false,
	dark_float = false,
}
