require("stabilize").setup{
	nested = "QuickFixCmdPost,DiagnosticChanged *"
}
