require("aerial").setup({
    backends = { "lsp", "treesitter", "markdown" },
    manage_folds= true,
    max_width = 100,
    link_folds_to_tree = true,

})
